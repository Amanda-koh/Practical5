import 'package:flutter/material.dart';
import 'package:helloflutter/cart_provider.dart';
import 'package:provider/provider.dart';
import 'item.dart';
import 'cart.dart';

final List<Item> catalog = [
  Item(1, 'Shoes'),
  Item(2, 'Hats'),
  Item(3, 'Shirts'),
  Item(4, 'Tie'),
  Item(5, 'Pants'),
  Item(6, 'Jeans'),
  Item(7, 'Shorts'),
  Item(8, 'Underwear'),
  Item(9, 'Jumpers'),
  Item(10, 'Trousers'),
  Item(11, 'Sleepwear'),
  Item(12, 'Accessories'),
];

void main() {
  runApp(ChangeNotifierProvider(
      create: (context)=> CartProvider(), child: const MainApp()));
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      home: MyHomePage()
    );
  }
}

class MyHomePage extends StatefulWidget{
  const MyHomePage({super.key});

  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage>{
  Widget build(BuildContext context){
    return Scaffold(
      appBar: AppBar(
        title: Text('State Management'),
        actions: [
          IconButton(
              onPressed: (){
                Navigator.push(context,
                    MaterialPageRoute(builder: (context)=> CartPage()));
              },
              icon: Icon(Icons.shopping_cart))
        ],
      ),
      body: Center(
        child: ListView.separated(
            padding: const EdgeInsets.all(8),
            scrollDirection: Axis.vertical,
            shrinkWrap: true,
            itemBuilder: (BuildContext context, int index){
              return CartItem(index: index);
            },
            separatorBuilder: (BuildContext context, int index)=>Divider(),
            itemCount: catalog.length),
      ),
    );
  }
}

class CartItem extends StatelessWidget {
  final int index;
  const CartItem({super.key, required this.index});

  @override
  Widget build(BuildContext context) {
    var item = catalog[index];
    return Row(
      children: [
        Text('$item'),
        const Expanded(child: SizedBox()),
        Consumer<CartProvider> (builder: (context, cart, child){
          return TextButton(
              onPressed: (){
                cart.add(item);
                ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(content: Text('$item added to cart')));
              },
              child: const Text('Add'));
        })
      ],
    );
  }
}
